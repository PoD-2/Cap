import React from 'react'

function SellerProducts() {
    return (
        <div>
            <h3 className="sellerPageTitle">Products</h3>
            <span className="LineSeperator mb-3" />
        </div>
    )
}

export default SellerProducts
